

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="bacchus contact info">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">

    <title>Bacchus Restaurant - Contact Us</title>

    <link href="/css/bootstrap.css" rel="stylesheet">
    <link href="/css/sticky-footer.css" rel="stylesheet">
    <link href="/css/navbar-static-top.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">

  </head>

  <body>

    <!-- Static navbar -->
    <nav class="navbar navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/">
       <img style="max-width:100px; margin-top: -15px;"
             src="/images/bacchus.png">
          </a>
          <a class="navbar-brand" href="/">Bacchus Restaurant</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="/">Home</a></li>
            <li><a href="/photos.php">Photos</a></li>
            <li class="active"><a href="/contact.php">Contact</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

	
    <div class="container">
		
  		<div class="jumbotron">
  	    	<div class="row more-up">
  	    		<div class="col-md-10 col-md-offset-1 main-text">
              <h1>Contact Us</h1>

              <div class="container">
                <div class="row">
                  <form role="form" action="" method="post" >
                    <div class="col-lg-6">
                      <div class="well well-sm"><strong><i class="glyphicon glyphicon-ok form-control-feedback"></i> Required Field</strong></div>
                      <div class="form-group">
                        <label for="name">Your Name</label>
                        <div class="input-group">
                          <input type="text" class="form-control" name="name" id="name" placeholder="Enter Name" required value="">
                          <p class='text-danger'></p>                          <span class="input-group-addon"><i class="glyphicon glyphicon-ok form-control-feedback"></i></span></div>
                      </div>
                      <div class="form-group">
                        <label for="email">Your Email</label>
                        <div class="input-group">
                          <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" required  value="">
                          <p class='text-danger'></p>                          <span class="input-group-addon"><i class="glyphicon glyphicon-ok form-control-feedback"></i></span></div>
                      </div>
                      <div class="form-group">
                        <label for="message">Message</label>
                        <div class="input-group">
                          <textarea name="message" id="message" class="form-control" rows="5" required></textarea>
                          <p class='text-danger'></p>                          <span class="input-group-addon"><i class="glyphicon glyphicon-ok form-control-feedback"></i></span></div>
                      </div>
                      <div class="form-group">
                        <label for="human">What is 4+3? (Simple Spam Checker)</label>
                        <div class="input-group">
                          <input type="text" class="form-control" name="human" id="human" required>
                          <p class='text-danger'></p>                          <span class="input-group-addon"><i class="glyphicon glyphicon-ok form-control-feedback"></i></span></div>
                      </div>
                      <div class="form-group">
                        <div class="input-group">
                          <input type="submit" name="submit" id="submit" value="Submit" class="btn btn-info pull-right">
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="input-group">
                            
                        </div>
                      </div>
                    </div>
                  </form>
                  <hr class="featurette-divider hidden-lg">
                  <div class="col-lg-5 col-md-push-1">
                    <address>
                    <h3>Our Location</h3>
                    <p><div class="google-maps">
                      <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script><div style="overflow:hidden;height:350;width:370px;"><div id="gmap_canvas" style="height:500px;width:600px;"></div><style>#gmap_canvas img{max-width:none!important;background:none!important}</style><a class="google-map-code" href="http://wordpress-hosting.me" id="get-map-data">http://wordpress-hosting.me</a></div><script type="text/javascript"> function init_map(){var myOptions = {zoom:17,center:new google.maps.LatLng(39.48189024302799,19.931701645043972),mapTypeId: google.maps.MapTypeId.HYBRID};map = new google.maps.Map(document.getElementById("gmap_canvas"), myOptions);marker = new google.maps.Marker({map: map,position: new google.maps.LatLng(39.48189024302799, 19.931701645043972)});infowindow = new google.maps.InfoWindow({content:"<b>Bacchus</b><br/>Messonghi<br/>49100 Corfu" });google.maps.event.addListener(marker, "click", function(){infowindow.open(map,marker);});infowindow.open(map,marker);}google.maps.event.addDomListener(window, 'load', init_map);</script>
                    </div>
                    </p>
                      <p><b>E-mail:</b> info@bacchus.gr</p>
                      <p><b>Phone:</b> +30 26610 75301</p>
                      <p><div id="TA_certificateOfExcellence888" class="TA_certificateOfExcellence">
                      <ul id="7VO2fpw" class="TA_links wYY2BpkSFUn">
                      <li id="srRfYTnf20G" class="OZbLXQ">
                      <a target="_blank" href="http://www.tripadvisor.com/Restaurant_Review-g1073595-d2572148-Reviews-Bacchus_Restaurant-Messonghi_Corfu_Ionian_Islands.html"><img src="http://www.tripadvisor.com/img/cdsi/img2/awards/CoE2015_WidgetAsset-14348-2.png" alt="TripAdvisor" class="widCOEImg" id="CDSWIDCOELOGO"/></a>
                      </li>
                      </ul>
                      </div>
                      <script src="http://www.jscache.com/wejs?wtype=certificateOfExcellence&amp;uniq=888&amp;locationId=2572148&amp;lang=en_US&amp;year=2015&amp;display_version=2"></script>
                      </p>
                    </address>
                  </div>
                </div>
              </div>
  	    		</div>
  	    	</div>
      	</div>
      </div> <!-- /container -->


    <footer class="footer">
      <div class="container">
        <p class="text-muted">Copyright © 2015 Bacchus.gr. All rights reserved.</p>
      </div>
    </footer>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/jquery.magnific-popup.js"></script>
    <script src="/js/zoom-gallery.js"></script>
  </body>
</html>
