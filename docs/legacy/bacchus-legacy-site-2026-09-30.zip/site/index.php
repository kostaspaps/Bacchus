<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="bacchus main-page">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <title>Bacchus Restaurant - Home Page</title>

    <link href="/css/bootstrap.css" rel="stylesheet">
    <link href="/css/sticky-footer.css" rel="stylesheet">
    <link href="/css/navbar-static-top.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">

  </head>

  <body>

    <!-- Static navbar -->
    <nav class="navbar navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/">
			 <img style="max-width:100px; margin-top: -15px;"
             src="/images/bacchus.png">
          </a>
          <a class="navbar-brand" href="/">Bacchus Restaurant</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="/">Home</a></li>
            <li><a href="/photos.php">Photos</a></li>
            <li><a href="/contact.php">Contact</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

	
    <div class="container">
  		<div class="jumbotron">
	    	<div class="row">
          <div class="col-md-12"><img class="main-image" src="/images/Restaurant/05.png" height="300" /></div>
	    		<div class="col-md-10 col-md-offset-1 main-text">

	    			<h1>Welcome to "BACCHUS" Restaurant</h1>
	    			
	    				<p>In the south part of Corfu island you can have an unforgettable experience with a dinner in Bacchus, one of the best traditional Greek restaurants on the island. 
	Bacchus restaurant is placed right on the gorgeous sandy beach of Messonghi. 
	Corfu-Kerkyra.eu wish to suggest you this restaurant for the great variety and excellent quality of the starters, the main dishes and especially the fish you can taste. 
	Dimitris, the owner of Bacchus restaurant has a 30 years experience as Chef cuisine in Greece. 
	Every summer from the beginning of May till the end of October he gives the opportunity to taste authentic Greek food both for lunch and dinner to all the tourists who will visit Corfu island.</p>	
	    			
					<hr>
					<p><b>Bacchus</b> is a family-run restaurant and the chef Dimitris will prepare for you the meal while his wife Yana and his sons will welcome you ready to satisfy all your request.
Here you can taste all the most traditional recipes from Corfu together with creative Greek dishes like <b>lamb cooked in lemon sauce, Samiotiko</b> which is pork fillet with sesame seeds in Samos wine sauce and lots more.
We like especially to suggest you <b>Bacchus restaurant</b> for the superb quality of the fish you can order here. 
There’s always a large choice of fresh fish brought by local fishermen ready to be grilled or special plates such as <b>grilled squids stuffed with local cheese</b> or small <b>marinated fresh fishes</b>.
After the meal we suggest you to order a dessert as they are prepared fresh every day and they change from time to time according to the chef inspiration. 
The passion and the care used by the owner to prepare the different Greek specialities and the charming atmosphere in front of the sea are some of the reasons why Bacchus restaurant has been honoured with the presence of celebrities, politics and local authorities of Corfu.</p>

	    		</div>
	    	</div>
    	</div>
    </div> <!-- /container -->


    <footer class="footer">
      <div class="container">
        <p class="text-muted">Copyright © 2015 - 2021 Bacchus.gr. All rights reserved.</p>
      </div>
    </footer>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
  </body>
</html>
