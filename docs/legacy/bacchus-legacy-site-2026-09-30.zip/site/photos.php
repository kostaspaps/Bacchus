<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="bacchus photos">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">

    <title>Bacchus Restaurant - Photos</title>

    <link href="/css/bootstrap.css" rel="stylesheet">
    <link href="/css/sticky-footer.css" rel="stylesheet">
    <link href="/css/navbar-static-top.css" rel="stylesheet">
    <link href="/css/magnific-popup.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">

  </head>

  <body>

    <!-- Static navbar -->
    <nav class="navbar navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="/">
       <img style="max-width:100px; margin-top: -15px;"
             src="/images/bacchus.png">
          </a>
          <a class="navbar-brand" href="/">Bacchus Restaurant</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="/">Home</a></li>
            <li class="active"><a href="/photos.php">Photos</a></li>
            <li><a href="/contact.php">Contact</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>


    <div class="container">

  		<div class="jumbotron">
  	    	<div class="row more-up">
  	    		<div class="col-md-10 col-md-offset-1 main-text">

              <div class="rest-photos">
                <h1>Our Restaurant</h1>
                <div class="html-code grid-of-images">
                  <div class="zoom-gallery2">

                    <a href="/images/Restaurant/01.JPG" title="Restaurant 01" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/01.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/02.JPG" title="Restaurant 02" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/02.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/03.JPG" title="Restaurant 03" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/03.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/04.JPG" title="Restaurant 04" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/04.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/05.JPG" title="Restaurant 05" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/05.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/06.JPG" title="Restaurant 06" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/06.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/07.JPG" title="Restaurant 07" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/07.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/08.JPG" title="Restaurant 08" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/08.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/09.JPG" title="Restaurant 09" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/09.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/10.JPG" title="Restaurant 10" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/10.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/11.JPG" title="Restaurant 11" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/11.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/12.JPG" title="Restaurant 12" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/12.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/13.JPG" title="Restaurant 13" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/13.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/14.JPG" title="Restaurant 14" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/14.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/14.JPG" title="Restaurant 14" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/14.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/15.JPG" title="Restaurant 15" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/15.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/16.JPG" title="Restaurant 16" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/16.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/17.JPG" title="Restaurant 17" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/17.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/18.JPG" title="Restaurant 18" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/18.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/19.JPG" title="Restaurant 19" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/19.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/20.JPG" title="Restaurant 20" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/20.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Restaurant/21.JPG" title="Restaurant 21" style="width:193px;height:125px;">
                      <img src="/images/Restaurant/21.JPG" width="193" height="125" />
                    </a>
                  </div>
                </div>
              </div>

              <div class="food-photos">
                <h1>Our Food</h1>
                <div class="html-code grid-of-images">
                  <div class="zoom-gallery">

                    <a href="/images/Food/01.JPG" title="Food 01" style="width:193px;height:125px;">
                      <img src="/images/Food/01.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/02.JPG" title="Food 02" style="width:193px;height:125px;">
                      <img src="/images/Food/02.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/03.JPG" title="Food 03" style="width:193px;height:125px;">
                      <img src="/images/Food/03.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/04.JPG" title="Food 04" style="width:193px;height:125px;">
                      <img src="/images/Food/04.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/05.JPG" title="Food 05" style="width:193px;height:125px;">
                      <img src="/images/Food/05.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/06.JPG" title="Food 06" style="width:193px;height:125px;">
                      <img src="/images/Food/06.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/07.JPG" title="Food 07" style="width:193px;height:125px;">
                      <img src="/images/Food/07.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/08.JPG" title="Food 08" style="width:193px;height:125px;">
                      <img src="/images/Food/08.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/09.JPG" title="Food 09" style="width:193px;height:125px;">
                      <img src="/images/Food/09.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/10.JPG" title="Food 10" style="width:193px;height:125px;">
                      <img src="/images/Food/10.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/11.JPG" title="Food 11" style="width:193px;height:125px;">
                      <img src="/images/Food/11.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/12.JPG" title="Food 12" style="width:193px;height:125px;">
                      <img src="/images/Food/12.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/13.JPG" title="Food 13" style="width:193px;height:125px;">
                      <img src="/images/Food/13.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/14.JPG" title="Food 14" style="width:193px;height:125px;">
                      <img src="/images/Food/14.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/15.JPG" title="Food 15" style="width:193px;height:125px;">
                      <img src="/images/Food/15.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/16.JPG" title="Food 16" style="width:193px;height:125px;">
                      <img src="/images/Food/16.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/17.JPG" title="Food 17" style="width:193px;height:125px;">
                      <img src="/images/Food/17.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/18.JPG" title="Food 18" style="width:193px;height:125px;">
                      <img src="/images/Food/18.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/19.JPG" title="Food 19" style="width:193px;height:125px;">
                      <img src="/images/Food/19.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/20.JPG" title="Food 20" style="width:193px;height:125px;">
                      <img src="/images/Food/20.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/21.JPG" title="Food 21" style="width:193px;height:125px;">
                      <img src="/images/Food/21.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/22.JPG" title="Food 22" style="width:193px;height:125px;">
                      <img src="/images/Food/22.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/23.JPG" title="Food 23" style="width:193px;height:125px;">
                      <img src="/images/Food/23.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/24.JPG" title="Food 24" style="width:193px;height:125px;">
                      <img src="/images/Food/24.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/25.JPG" title="Food 25" style="width:193px;height:125px;">
                      <img src="/images/Food/25.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/26.JPG" title="Food 26" style="width:193px;height:125px;">
                      <img src="/images/Food/26.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/27.JPG" title="Food 27" style="width:193px;height:125px;">
                      <img src="/images/Food/27.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/28.JPG" title="Food 28" style="width:193px;height:125px;">
                      <img src="/images/Food/28.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/29.JPG" title="Food 29" style="width:193px;height:125px;">
                      <img src="/images/Food/29.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/30.JPG" title="Food 30" style="width:193px;height:125px;">
                      <img src="/images/Food/30.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/31.JPG" title="Food 31" style="width:193px;height:125px;">
                      <img src="/images/Food/31.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/32.JPG" title="Food 32" style="width:193px;height:125px;">
                      <img src="/images/Food/32.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/33.JPG" title="Food 33" style="width:193px;height:125px;">
                      <img src="/images/Food/33.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/34.JPG" title="Food 34" style="width:193px;height:125px;">
                      <img src="/images/Food/34.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/35.JPG" title="Food 35" style="width:193px;height:125px;">
                      <img src="/images/Food/35.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/36.JPG" title="Food 36" style="width:193px;height:125px;">
                      <img src="/images/Food/36.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/37.JPG" title="Food 37" style="width:193px;height:125px;">
                      <img src="/images/Food/37.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/38.JPG" title="Food 38" style="width:193px;height:125px;">
                      <img src="/images/Food/38.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/39.JPG" title="Food 39" style="width:193px;height:125px;">
                      <img src="/images/Food/39.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/40.JPG" title="Food 40" style="width:193px;height:125px;">
                      <img src="/images/Food/40.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/41.JPG" title="Food 41" style="width:193px;height:125px;">
                      <img src="/images/Food/41.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/42.JPG" title="Food 42" style="width:193px;height:125px;">
                      <img src="/images/Food/42.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/43.JPG" title="Food 43" style="width:193px;height:125px;">
                      <img src="/images/Food/43.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/44.JPG" title="Food 44" style="width:193px;height:125px;">
                      <img src="/images/Food/44.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/45.JPG" title="Food 45" style="width:193px;height:125px;">
                      <img src="/images/Food/45.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/46.JPG" title="Food 46" style="width:193px;height:125px;">
                      <img src="/images/Food/46.JPG" width="193" height="125" />
                    </a>
                    <a href="/images/Food/47.JPG" title="Food 47" style="width:193px;height:125px;">
                      <img src="/images/Food/47.JPG" width="193" height="125" />
                    </a>
                  </div>
                </div>
              </div>

  	    		</div>
  	    	</div>
      	</div>
      </div> <!-- /container -->


    <footer class="footer">
      <div class="container">
        <p class="text-muted">Copyright © 2015 Bacchus.gr. All rights reserved.</p>
      </div>
    </footer>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/jquery.magnific-popup.js"></script>
    <script src="/js/zoom-gallery.js"></script>
  </body>
</html>
